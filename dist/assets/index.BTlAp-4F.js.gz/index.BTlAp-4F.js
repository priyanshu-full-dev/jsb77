import{a as b,r as h}from"./index.DrYkcnFZ.js";function Z(t){var e,a,o="";if(typeof t=="string"||typeof t=="number")o+=t;else if(typeof t=="object")if(Array.isArray(t)){var r=t.length;for(e=0;e<r;e++)t[e]&&(a=Z(t[e]))&&(o&&(o+=" "),o+=a)}else for(a in t)t[a]&&(o&&(o+=" "),o+=a);return o}function R(){for(var t,e,a=0,o="",r=arguments.length;a<r;a++)(t=arguments[a])&&(e=Z(t))&&(o&&(o+=" "),o+=e);return o}var M=t=>typeof t=="number"&&!isNaN(t),D=t=>typeof t=="string",P=t=>typeof t=="function",lt=t=>D(t)||M(t),K=t=>D(t)||P(t)?t:null,ft=(t,e)=>t===!1||M(t)&&t>0?t:e,Y=t=>h.isValidElement(t)||D(t)||P(t)||M(t);function ct(t,e,a=300){let{scrollHeight:o,style:r}=t;requestAnimationFrame(()=>{r.minHeight="initial",r.height=o+"px",r.transition=`all ${a}ms`,requestAnimationFrame(()=>{r.height="0",r.padding="0",r.margin="0",setTimeout(e,a)})})}function dt({enter:t,exit:e,appendPosition:a=!1,collapse:o=!0,collapseDuration:r=300}){return function({children:l,position:s,preventExitTransition:d,done:f,nodeRef:y,isIn:_,playToast:k}){let w=a?`${t}--${s}`:t,E=a?`${e}--${s}`:e,C=h.useRef(0);return h.useLayoutEffect(()=>{let T=y.current,p=w.split(" "),m=n=>{n.target===y.current&&(k(),T.removeEventListener("animationend",m),T.removeEventListener("animationcancel",m),C.current===0&&n.type!=="animationcancel"&&T.classList.remove(...p))};T.classList.add(...p),T.addEventListener("animationend",m),T.addEventListener("animationcancel",m)},[]),h.useEffect(()=>{let T=y.current,p=()=>{T.removeEventListener("animationend",p),o?ct(T,f,r):f()};_||(d?p():(C.current=1,T.className+=` ${E}`,T.addEventListener("animationend",p)))},[_]),b.createElement(b.Fragment,null,l)}}function G(t,e){return{content:tt(t.content,t.props),containerId:t.props.containerId,id:t.props.toastId,theme:t.props.theme,type:t.props.type,data:t.props.data||{},isLoading:t.props.isLoading,icon:t.props.icon,reason:t.removalReason,status:e}}function tt(t,e,a=!1){return h.isValidElement(t)&&!D(t.type)?h.cloneElement(t,{closeToast:e.closeToast,toastProps:e,data:e.data,isPaused:a}):P(t)?t({closeToast:e.closeToast,toastProps:e,data:e.data,isPaused:a}):t}function ut({closeToast:t,theme:e,ariaLabel:a="close"}){return b.createElement("button",{className:`Toastify__close-button Toastify__close-button--${e}`,type:"button",onClick:o=>{o.stopPropagation(),t(!0)},"aria-label":a},b.createElement("svg",{"aria-hidden":"true",viewBox:"0 0 14 16"},b.createElement("path",{fillRule:"evenodd",d:"M7.71 8.23l3.75 3.75-1.48 1.48-3.75-3.75-3.75 3.75L1 11.98l3.75-3.75L1 4.48 2.48 3l3.75 3.75L9.98 3l1.48 1.48-3.75 3.75z"})))}function yt({delay:t,isRunning:e,closeToast:a,type:o="default",hide:r,className:l,controlledProgress:s,progress:d,rtl:f,isIn:y,theme:_}){let k=r||s&&d===0,w={animationDuration:`${t}ms`,animationPlayState:e?"running":"paused"};s&&(w.transform=`scaleX(${d})`);let E=R("Toastify__progress-bar",s?"Toastify__progress-bar--controlled":"Toastify__progress-bar--animated",`Toastify__progress-bar-theme--${_}`,`Toastify__progress-bar--${o}`,{"Toastify__progress-bar--rtl":f}),C=P(l)?l({rtl:f,type:o,defaultClassName:E}):R(E,l),T={[s&&d>=1?"onTransitionEnd":"onAnimationEnd"]:s&&d<1?null:()=>{y&&a()}};return b.createElement("div",{className:"Toastify__progress-bar--wrp","data-hidden":k},b.createElement("div",{className:`Toastify__progress-bar--bg Toastify__progress-bar-theme--${_} Toastify__progress-bar--${o}`}),b.createElement("div",{role:"progressbar","aria-hidden":k?"true":"false","aria-label":"notification timer","aria-valuenow":s?Math.round(d*100):void 0,"aria-valuemin":0,"aria-valuemax":100,className:C,style:w,...T}))}var mt=1,et=()=>`${mt++}`;function pt(t,e,a){let o=1,r=0,l=[],s=[],d=e,f=new Map,y=new Set,_=n=>(y.add(n),()=>y.delete(n)),k=()=>{s=Array.from(f.values()),y.forEach(n=>n())},w=({containerId:n,toastId:i,updateId:c})=>{let x=n?n!==t:t!==1,L=f.has(i)&&c==null;return x||L},E=(n,i)=>{f.forEach(c=>{var x;(i==null||i===c.props.toastId)&&((x=c.toggle)==null||x.call(c,n))})},C=n=>{var i,c;n.isActive&&((c=(i=n.props)==null?void 0:i.onClose)==null||c.call(i,n.removalReason),n.isActive=!1,a(G(n,"removed")))},T=n=>{if(n==null)f.forEach(C);else{let i=f.get(n);i&&C(i)}k()},p=()=>{r-=l.length,l=[]},m=n=>{var i,c;let{toastId:x,updateId:L}=n.props,u=L==null;n.staleId&&f.delete(n.staleId),n.isActive=!0,f.set(x,n),k(),a(G(n,u?"added":"updated")),u&&((c=(i=n.props).onOpen)==null||c.call(i))};return{id:t,props:d,observe:_,toggle:E,removeToast:T,toasts:f,clearQueue:p,buildToast:(n,i)=>{if(w(i))return;let{toastId:c,updateId:x,data:L,staleId:u,delay:v}=i,O=x==null;O&&r++;let z={...d,style:d.toastStyle,key:o++,...Object.fromEntries(Object.entries(i).filter(([B,A])=>A!=null)),toastId:c,updateId:x,data:L,isIn:!1,className:K(i.className||d.toastClassName),progressClassName:K(i.progressClassName||d.progressClassName),autoClose:i.isLoading?!1:ft(i.autoClose,d.autoClose),closeToast(B){let A=f.get(c);A&&(A.removalReason=B,T(c))},deleteToast(){if(f.get(c)!=null){if(f.delete(c),r--,r<0&&(r=0),l.length>0){m(l.shift());return}k()}}};z.closeButton=d.closeButton,i.closeButton===!1||Y(i.closeButton)?z.closeButton=i.closeButton:i.closeButton===!0&&(z.closeButton=Y(d.closeButton)?d.closeButton:!0);let $={content:n,props:z,staleId:u};d.limit&&d.limit>0&&r>d.limit&&O?l.push($):M(v)?setTimeout(()=>{m($)},v):m($)},setProps(n){d=n},setToggle:(n,i)=>{let c=f.get(n);c&&(c.toggle=i)},isToastActive:n=>{var i;return(i=f.get(n))==null?void 0:i.isActive},getSnapshot:()=>s}}var I=new Map,N=[],Q=new Set,_t=t=>Q.forEach(e=>e(t)),at=()=>I.size>0;function gt(){N.forEach(t=>rt(t.content,t.options)),N=[]}var vt=(t,{containerId:e})=>{var a;return(a=I.get(e||1))==null?void 0:a.toasts.get(t)};function ot(t,e){var a;if(e)return!!((a=I.get(e))!=null&&a.isToastActive(t));let o=!1;return I.forEach(r=>{r.isToastActive(t)&&(o=!0)}),o}function bt(t){if(!at()){N=N.filter(e=>t!=null&&e.options.toastId!==t);return}if(t==null||lt(t))I.forEach(e=>{e.removeToast(t)});else if(t&&("containerId"in t||"id"in t)){let e=I.get(t.containerId);e?e.removeToast(t.id):I.forEach(a=>{a.removeToast(t.id)})}}var Tt=(t={})=>{I.forEach(e=>{e.props.limit&&(!t.containerId||e.id===t.containerId)&&e.clearQueue()})};function rt(t,e){Y(t)&&(at()||N.push({content:t,options:e}),I.forEach(a=>{a.buildToast(t,e)}))}function ht(t){var e;(e=I.get(t.containerId||1))==null||e.setToggle(t.id,t.fn)}function st(t,e){I.forEach(a=>{(e==null||!(e!=null&&e.containerId)||(e==null?void 0:e.containerId)===a.id)&&a.toggle(t,e==null?void 0:e.id)})}function xt(t){let e=t.containerId||1;return{subscribe(a){let o=pt(e,t,_t);I.set(e,o);let r=o.observe(a);return gt(),()=>{r(),I.delete(e)}},setProps(a){var o;(o=I.get(e))==null||o.setProps(a)},getSnapshot(){var a;return(a=I.get(e))==null?void 0:a.getSnapshot()}}}function kt(t){return Q.add(t),()=>{Q.delete(t)}}function Et(t){return t&&(D(t.toastId)||M(t.toastId))?t.toastId:et()}function S(t,e){return rt(t,e),e.toastId}function U(t,e){return{...e,type:e&&e.type||t,toastId:Et(e)}}function H(t){return(e,a)=>S(e,U(t,a))}function g(t,e){return S(t,U("default",e))}g.loading=(t,e)=>S(t,U("default",{isLoading:!0,autoClose:!1,closeOnClick:!1,closeButton:!1,draggable:!1,...e}));function wt(t,{pending:e,error:a,success:o},r){let l;e&&(l=D(e)?g.loading(e,r):g.loading(e.render,{...r,...e}));let s={isLoading:null,autoClose:null,closeOnClick:null,closeButton:null,draggable:null},d=(y,_,k)=>{if(_==null){g.dismiss(l);return}let w={type:y,...s,...r,data:k},E=D(_)?{render:_}:_;return l?g.update(l,{...w,...E}):g(E.render,{...w,...E}),k},f=P(t)?t():t;return f.then(y=>d("success",o,y)).catch(y=>d("error",a,y)),f}g.promise=wt;g.success=H("success");g.info=H("info");g.error=H("error");g.warning=H("warning");g.warn=g.warning;g.dark=(t,e)=>S(t,U("default",{theme:"dark",...e}));function It(t){bt(t)}g.dismiss=It;g.clearWaitingQueue=Tt;g.isActive=ot;g.update=(t,e={})=>{let a=vt(t,e);if(a){let{props:o,content:r}=a,l={delay:100,...o,...e,toastId:e.toastId||t,updateId:et()};l.toastId!==t&&(l.staleId=t);let s=l.render||r;delete l.render,S(s,l)}};g.done=t=>{g.update(t,{progress:1})};g.onChange=kt;g.play=t=>st(!0,t);g.pause=t=>st(!1,t);function Ct(t){var e;let{subscribe:a,getSnapshot:o,setProps:r}=h.useRef(xt(t)).current;r(t);let l=(e=h.useSyncExternalStore(a,o,o))==null?void 0:e.slice();function s(d){if(!l)return[];let f=new Map;return t.newestOnTop&&l.reverse(),l.forEach(y=>{let{position:_}=y.props;f.has(_)||f.set(_,[]),f.get(_).push(y)}),Array.from(f,y=>d(y[0],y[1]))}return{getToastToRender:s,isToastActive:ot,count:l==null?void 0:l.length}}function Lt(t){let[e,a]=h.useState(!1),[o,r]=h.useState(!1),l=h.useRef(null),s=h.useRef({start:0,delta:0,removalDistance:0,canCloseOnClick:!0,canDrag:!1,didMove:!1}).current,{autoClose:d,pauseOnHover:f,closeToast:y,onClick:_,closeOnClick:k}=t;ht({id:t.toastId,containerId:t.containerId,fn:a}),h.useEffect(()=>{if(t.pauseOnFocusLoss)return w(),()=>{E()}},[t.pauseOnFocusLoss]);function w(){document.hasFocus()||m(),window.addEventListener("focus",p),window.addEventListener("blur",m)}function E(){window.removeEventListener("focus",p),window.removeEventListener("blur",m)}function C(u){if(t.draggable===!0||t.draggable===u.pointerType){n();let v=l.current;s.canCloseOnClick=!0,s.canDrag=!0,v.style.transition="none",t.draggableDirection==="x"?(s.start=u.clientX,s.removalDistance=v.offsetWidth*(t.draggablePercent/100)):(s.start=u.clientY,s.removalDistance=v.offsetHeight*(t.draggablePercent===80?t.draggablePercent*1.5:t.draggablePercent)/100)}}function T(u){let{top:v,bottom:O,left:z,right:$}=l.current.getBoundingClientRect();u.pointerType==="mouse"&&t.pauseOnHover&&u.clientX>=z&&u.clientX<=$&&u.clientY>=v&&u.clientY<=O?m():p()}function p(){a(!0)}function m(){a(!1)}function n(){s.didMove=!1,document.addEventListener("pointermove",c),document.addEventListener("pointerup",x)}function i(){document.removeEventListener("pointermove",c),document.removeEventListener("pointerup",x)}function c(u){let v=l.current;if(s.canDrag&&v){s.didMove=!0,e&&m(),t.draggableDirection==="x"?s.delta=u.clientX-s.start:s.delta=u.clientY-s.start,s.start!==u.clientX&&(s.canCloseOnClick=!1);let O=t.draggableDirection==="x"?`${s.delta}px, var(--y)`:`0, calc(${s.delta}px + var(--y))`;v.style.transform=`translate3d(${O},0)`,v.style.opacity=`${1-Math.abs(s.delta/s.removalDistance)}`}}function x(){i();let u=l.current;if(s.canDrag&&s.didMove&&u){if(s.canDrag=!1,Math.abs(s.delta)>s.removalDistance){r(!0),t.closeToast(!0),t.collapseAll();return}u.style.transition="transform 0.2s, opacity 0.2s",u.style.removeProperty("transform"),u.style.removeProperty("opacity")}}let L={onPointerDown:C,onPointerUp:T};return d&&f&&(L.onMouseEnter=m,t.stacked||(L.onMouseLeave=p)),k&&(L.onClick=u=>{_&&_(u),s.canCloseOnClick&&y(!0)}),{playToast:p,pauseToast:m,isRunning:e,preventExitTransition:o,toastRef:l,eventHandlers:L}}var nt=typeof window<"u"?h.useLayoutEffect:h.useEffect,F=({theme:t,type:e,isLoading:a,...o})=>b.createElement("svg",{viewBox:"0 0 24 24",width:"100%",height:"100%",fill:t==="colored"?"currentColor":`var(--toastify-icon-color-${e})`,...o});function Ot(t){return b.createElement(F,{...t},b.createElement("path",{d:"M23.32 17.191L15.438 2.184C14.728.833 13.416 0 11.996 0c-1.42 0-2.733.833-3.443 2.184L.533 17.448a4.744 4.744 0 000 4.368C1.243 23.167 2.555 24 3.975 24h16.05C22.22 24 24 22.044 24 19.632c0-.904-.251-1.746-.68-2.44zm-9.622 1.46c0 1.033-.724 1.823-1.698 1.823s-1.698-.79-1.698-1.822v-.043c0-1.028.724-1.822 1.698-1.822s1.698.79 1.698 1.822v.043zm.039-12.285l-.84 8.06c-.057.581-.408.943-.897.943-.49 0-.84-.367-.896-.942l-.84-8.065c-.057-.624.25-1.095.779-1.095h1.91c.528.005.84.476.784 1.1z"}))}function zt(t){return b.createElement(F,{...t},b.createElement("path",{d:"M12 0a12 12 0 1012 12A12.013 12.013 0 0012 0zm.25 5a1.5 1.5 0 11-1.5 1.5 1.5 1.5 0 011.5-1.5zm2.25 13.5h-4a1 1 0 010-2h.75a.25.25 0 00.25-.25v-4.5a.25.25 0 00-.25-.25h-.75a1 1 0 010-2h1a2 2 0 012 2v4.75a.25.25 0 00.25.25h.75a1 1 0 110 2z"}))}function $t(t){return b.createElement(F,{...t},b.createElement("path",{d:"M12 0a12 12 0 1012 12A12.014 12.014 0 0012 0zm6.927 8.2l-6.845 9.289a1.011 1.011 0 01-1.43.188l-4.888-3.908a1 1 0 111.25-1.562l4.076 3.261 6.227-8.451a1 1 0 111.61 1.183z"}))}function Pt(t){return b.createElement(F,{...t},b.createElement("path",{d:"M11.983 0a12.206 12.206 0 00-8.51 3.653A11.8 11.8 0 000 12.207 11.779 11.779 0 0011.8 24h.214A12.111 12.111 0 0024 11.791 11.766 11.766 0 0011.983 0zM10.5 16.542a1.476 1.476 0 011.449-1.53h.027a1.527 1.527 0 011.523 1.47 1.475 1.475 0 01-1.449 1.53h-.027a1.529 1.529 0 01-1.523-1.47zM11 12.5v-6a1 1 0 012 0v6a1 1 0 11-2 0z"}))}function At(){return b.createElement("div",{className:"Toastify__spinner"})}var V={info:zt,warning:Ot,success:$t,error:Pt,spinner:At},Rt=t=>t in V;function Dt({theme:t,type:e,isLoading:a,icon:o}){let r=null,l={theme:t,type:e};return o===!1||(P(o)?r=o({...l,isLoading:a}):h.isValidElement(o)?r=h.cloneElement(o,l):a?r=V.spinner():Rt(e)&&(r=V[e](l))),r}var Nt=t=>{let{isRunning:e,preventExitTransition:a,toastRef:o,eventHandlers:r,playToast:l}=Lt(t),{closeButton:s,children:d,autoClose:f,onClick:y,type:_,hideProgressBar:k,closeToast:w,transition:E,position:C,className:T,style:p,progressClassName:m,updateId:n,role:i,progress:c,rtl:x,toastId:L,deleteToast:u,isIn:v,isLoading:O,closeOnClick:z,theme:$,ariaLabel:B}=t,A=R("Toastify__toast",`Toastify__toast-theme--${$}`,`Toastify__toast--${_}`,{"Toastify__toast--rtl":x},{"Toastify__toast--close-on-click":z}),it=P(T)?T({rtl:x,position:C,type:_,defaultClassName:A}):R(A,T),j=Dt(t),W=!!c||!f,q={closeToast:w,type:_,theme:$},X=null;return s===!1||(P(s)?X=s(q):h.isValidElement(s)?X=h.cloneElement(s,q):X=ut(q)),b.createElement(E,{isIn:v,done:u,position:C,preventExitTransition:a,nodeRef:o,playToast:l},b.createElement("div",{id:L,tabIndex:0,onClick:y,"data-in":v,className:it,...r,style:p,ref:o,...v&&{role:i,"aria-label":B}},j!=null&&b.createElement("div",{className:R("Toastify__toast-icon",{"Toastify--animate-icon Toastify__zoom-enter":!O})},j),tt(d,t,!e),X,!t.customProgressBar&&b.createElement(yt,{...n&&!W?{key:`p-${n}`}:{},rtl:x,theme:$,delay:f,isRunning:e,isIn:v,closeToast:w,hide:k,type:_,className:m,controlledProgress:W,progress:c||0})))},Mt=(t,e=!1)=>({enter:`Toastify--animate Toastify__${t}-enter`,exit:`Toastify--animate Toastify__${t}-exit`,appendPosition:e}),St=dt(Mt("bounce",!0)),Bt={position:"top-right",transition:St,autoClose:5e3,closeButton:!0,pauseOnHover:!0,pauseOnFocusLoss:!0,draggable:"touch",draggablePercent:80,draggableDirection:"x",role:"alert",theme:"light","aria-label":"Notifications Alt+T",hotKeys:t=>t.altKey&&t.code==="KeyT"};function Xt(t){let e={...Bt,...t},a=t.stacked,[o,r]=h.useState(!0),l=h.useRef(null),{getToastToRender:s,isToastActive:d,count:f}=Ct(e),{className:y,style:_,rtl:k,containerId:w,hotKeys:E}=e;function C(p){let m=R("Toastify__toast-container",`Toastify__toast-container--${p}`,{"Toastify__toast-container--rtl":k});return P(y)?y({position:p,rtl:k,defaultClassName:m}):R(m,K(y))}function T(){a&&(r(!0),g.play())}return nt(()=>{var p;if(a){let m=l.current.querySelectorAll('[data-in="true"]'),n=12,i=(p=e.position)==null?void 0:p.includes("top"),c=0,x=0;Array.from(m).reverse().forEach((L,u)=>{let v=L;v.classList.add("Toastify__toast--stacked"),u>0&&(v.dataset.collapsed=`${o}`),v.dataset.pos||(v.dataset.pos=i?"top":"bot");let O=c*(o?.2:1)+(o?0:n*u),z=Math.max(.5,1-(o?x:0));v.style.setProperty("--y",`${i?O:O*-1}px`),v.style.setProperty("--g",`${n}`),v.style.setProperty("--s",`${z}`),c+=v.offsetHeight,x+=.025})}},[o,f,a]),h.useEffect(()=>{function p(m){var n;let i=l.current;E(m)&&((n=i==null?void 0:i.querySelector('[tabIndex="0"]'))==null||n.focus(),r(!1),g.pause()),m.key==="Escape"&&(document.activeElement===i||i!=null&&i.contains(document.activeElement))&&(r(!0),g.play())}return document.addEventListener("keydown",p),()=>{document.removeEventListener("keydown",p)}},[E]),b.createElement("section",{ref:l,className:"Toastify",id:w,onMouseEnter:()=>{a&&(r(!1),g.pause())},onMouseLeave:T,"aria-live":"polite","aria-atomic":"false","aria-relevant":"additions text","aria-label":e["aria-label"]},s((p,m)=>{let n=m.length?{..._}:{..._,pointerEvents:"none"};return b.createElement("div",{tabIndex:-1,className:C(p),"data-stacked":a,style:n,key:`c-${p}`},m.map(({content:i,props:c})=>b.createElement(Nt,{...c,stacked:a,collapseAll:T,isIn:d(c.toastId,c.containerId),key:`t-${c.key}`},i)))}))}var Ut=`:root {
  --toastify-color-light: #fff;
  --toastify-color-dark: #121212;
  --toastify-color-info: #3498db;
  --toastify-color-success: #07bc0c;
  --toastify-color-warning: #f1c40f;
  --toastify-color-error: hsl(6, 78%, 57%);
  --toastify-color-transparent: rgba(255, 255, 255, 0.7);

  --toastify-icon-color-info: var(--toastify-color-info);
  --toastify-icon-color-success: var(--toastify-color-success);
  --toastify-icon-color-warning: var(--toastify-color-warning);
  --toastify-icon-color-error: var(--toastify-color-error);

  --toastify-container-width: fit-content;
  --toastify-toast-width: 320px;
  --toastify-toast-offset: 16px;
  --toastify-toast-top: max(var(--toastify-toast-offset), env(safe-area-inset-top));
  --toastify-toast-right: max(var(--toastify-toast-offset), env(safe-area-inset-right));
  --toastify-toast-left: max(var(--toastify-toast-offset), env(safe-area-inset-left));
  --toastify-toast-bottom: max(var(--toastify-toast-offset), env(safe-area-inset-bottom));
  --toastify-toast-background: #fff;
  --toastify-toast-padding: 14px;
  --toastify-toast-min-height: 64px;
  --toastify-toast-max-height: 800px;
  --toastify-toast-bd-radius: 6px;
  --toastify-toast-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
  --toastify-font-family: sans-serif;
  --toastify-z-index: 9999;
  --toastify-text-color-light: #757575;
  --toastify-text-color-dark: #fff;

  /* Used only for colored theme */
  --toastify-text-color-info: #fff;
  --toastify-text-color-success: #fff;
  --toastify-text-color-warning: #fff;
  --toastify-text-color-error: #fff;

  --toastify-spinner-color: #616161;
  --toastify-spinner-color-empty-area: #e0e0e0;
  --toastify-color-progress-light: linear-gradient(to right, #4cd964, #5ac8fa, #007aff, #34aadc, #5856d6, #ff2d55);
  --toastify-color-progress-dark: #bb86fc;
  --toastify-color-progress-info: var(--toastify-color-info);
  --toastify-color-progress-success: var(--toastify-color-success);
  --toastify-color-progress-warning: var(--toastify-color-warning);
  --toastify-color-progress-error: var(--toastify-color-error);
  /* used to control the opacity of the progress trail */
  --toastify-color-progress-bgo: 0.2;
}

.Toastify__toast-container {
  z-index: var(--toastify-z-index);
  -webkit-transform: translate3d(0, 0, var(--toastify-z-index));
  position: fixed;
  width: var(--toastify-container-width);
  box-sizing: border-box;
  color: #fff;
  display: flex;
  flex-direction: column;
}

.Toastify__toast-container--top-left {
  top: var(--toastify-toast-top);
  left: var(--toastify-toast-left);
}
.Toastify__toast-container--top-center {
  top: var(--toastify-toast-top);
  left: 50%;
  transform: translateX(-50%);
  align-items: center;
}
.Toastify__toast-container--top-right {
  top: var(--toastify-toast-top);
  right: var(--toastify-toast-right);
  align-items: end;
}
.Toastify__toast-container--bottom-left {
  bottom: var(--toastify-toast-bottom);
  left: var(--toastify-toast-left);
}
.Toastify__toast-container--bottom-center {
  bottom: var(--toastify-toast-bottom);
  left: 50%;
  transform: translateX(-50%);
  align-items: center;
}
.Toastify__toast-container--bottom-right {
  bottom: var(--toastify-toast-bottom);
  right: var(--toastify-toast-right);
  align-items: end;
}

.Toastify__toast {
  --y: 0px;
  position: relative;
  touch-action: none;
  width: var(--toastify-toast-width);
  min-height: var(--toastify-toast-min-height);
  box-sizing: border-box;
  margin-bottom: 1rem;
  padding: var(--toastify-toast-padding);
  border-radius: var(--toastify-toast-bd-radius);
  box-shadow: var(--toastify-toast-shadow);
  max-height: var(--toastify-toast-max-height);
  font-family: var(--toastify-font-family);
  /* webkit only issue #791 */
  z-index: 0;
  /* inner swag */
  display: flex;
  flex: 1 auto;
  align-items: center;
  word-break: break-word;
}

@media only screen and (max-width: 480px) {
  .Toastify__toast-container {
    width: 100vw;
    left: env(safe-area-inset-left);
    margin: 0;
  }
  .Toastify__toast-container--top-left,
  .Toastify__toast-container--top-center,
  .Toastify__toast-container--top-right {
    top: env(safe-area-inset-top);
    transform: translateX(0);
  }
  .Toastify__toast-container--bottom-left,
  .Toastify__toast-container--bottom-center,
  .Toastify__toast-container--bottom-right {
    bottom: env(safe-area-inset-bottom);
    transform: translateX(0);
  }
  .Toastify__toast-container--rtl {
    right: env(safe-area-inset-right);
    left: initial;
  }
  .Toastify__toast {
    --toastify-toast-width: 100%;
    margin-bottom: 0;
    border-radius: 0;
  }
}

.Toastify__toast-container[data-stacked='true'] {
  width: var(--toastify-toast-width);
}

@media only screen and (max-width: 480px) {
  .Toastify__toast-container[data-stacked='true'] {
    width: 100vw;
  }
}

.Toastify__toast--stacked {
  position: absolute;
  width: 100%;
  transform: translate3d(0, var(--y), 0) scale(var(--s));
  transition: transform 0.3s;
}

.Toastify__toast--stacked[data-collapsed] .Toastify__toast-body,
.Toastify__toast--stacked[data-collapsed] .Toastify__close-button {
  transition: opacity 0.1s;
}

.Toastify__toast--stacked[data-collapsed='false'] {
  overflow: visible;
}

.Toastify__toast--stacked[data-collapsed='true']:not(:last-child) > * {
  opacity: 0;
}

.Toastify__toast--stacked:after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  height: calc(var(--g) * 1px);
  bottom: 100%;
}

.Toastify__toast--stacked[data-pos='top'] {
  top: 0;
}

.Toastify__toast--stacked[data-pos='bot'] {
  bottom: 0;
}

.Toastify__toast--stacked[data-pos='bot'].Toastify__toast--stacked:before {
  transform-origin: top;
}

.Toastify__toast--stacked[data-pos='top'].Toastify__toast--stacked:before {
  transform-origin: bottom;
}

.Toastify__toast--stacked:before {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 100%;
  transform: scaleY(3);
  z-index: -1;
}

.Toastify__toast--rtl {
  direction: rtl;
}

.Toastify__toast--close-on-click {
  cursor: pointer;
}

.Toastify__toast-icon {
  margin-inline-end: 10px;
  width: 22px;
  flex-shrink: 0;
  display: flex;
}

.Toastify--animate {
  animation-fill-mode: both;
  animation-duration: 0.5s;
}

.Toastify--animate-icon {
  animation-fill-mode: both;
  animation-duration: 0.3s;
}

.Toastify__toast-theme--dark {
  background: var(--toastify-color-dark);
  color: var(--toastify-text-color-dark);
}

.Toastify__toast-theme--light {
  background: var(--toastify-color-light);
  color: var(--toastify-text-color-light);
}

.Toastify__toast-theme--colored.Toastify__toast--default {
  background: var(--toastify-color-light);
  color: var(--toastify-text-color-light);
}

.Toastify__toast-theme--colored.Toastify__toast--info {
  color: var(--toastify-text-color-info);
  background: var(--toastify-color-info);
}

.Toastify__toast-theme--colored.Toastify__toast--success {
  color: var(--toastify-text-color-success);
  background: var(--toastify-color-success);
}

.Toastify__toast-theme--colored.Toastify__toast--warning {
  color: var(--toastify-text-color-warning);
  background: var(--toastify-color-warning);
}

.Toastify__toast-theme--colored.Toastify__toast--error {
  color: var(--toastify-text-color-error);
  background: var(--toastify-color-error);
}

.Toastify__progress-bar-theme--light {
  background: var(--toastify-color-progress-light);
}

.Toastify__progress-bar-theme--dark {
  background: var(--toastify-color-progress-dark);
}

.Toastify__progress-bar--info {
  background: var(--toastify-color-progress-info);
}

.Toastify__progress-bar--success {
  background: var(--toastify-color-progress-success);
}

.Toastify__progress-bar--warning {
  background: var(--toastify-color-progress-warning);
}

.Toastify__progress-bar--error {
  background: var(--toastify-color-progress-error);
}

.Toastify__progress-bar-theme--colored.Toastify__progress-bar--info,
.Toastify__progress-bar-theme--colored.Toastify__progress-bar--success,
.Toastify__progress-bar-theme--colored.Toastify__progress-bar--warning,
.Toastify__progress-bar-theme--colored.Toastify__progress-bar--error {
  background: var(--toastify-color-transparent);
}

.Toastify__close-button {
  color: #fff;
  position: absolute;
  top: 6px;
  right: 6px;
  background: transparent;
  outline: none;
  border: none;
  padding: 0;
  cursor: pointer;
  opacity: 0.7;
  transition: 0.3s ease;
  z-index: 1;
}

.Toastify__toast--rtl .Toastify__close-button {
  left: 6px;
  right: unset;
}

.Toastify__close-button--light {
  color: #000;
  opacity: 0.3;
}

.Toastify__close-button > svg {
  fill: currentColor;
  height: 16px;
  width: 14px;
}

.Toastify__close-button:hover,
.Toastify__close-button:focus {
  opacity: 1;
}

@keyframes Toastify__trackProgress {
  0% {
    transform: scaleX(1);
  }
  100% {
    transform: scaleX(0);
  }
}

.Toastify__progress-bar {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  opacity: 0.7;
  transform-origin: left;
}

.Toastify__progress-bar--animated {
  animation: Toastify__trackProgress linear 1 forwards;
}

.Toastify__progress-bar--controlled {
  transition: transform 0.2s;
}

.Toastify__progress-bar--rtl {
  right: 0;
  left: initial;
  transform-origin: right;
  border-bottom-left-radius: initial;
}

.Toastify__progress-bar--wrp {
  position: absolute;
  overflow: hidden;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 5px;
  border-bottom-left-radius: var(--toastify-toast-bd-radius);
  border-bottom-right-radius: var(--toastify-toast-bd-radius);
}

.Toastify__progress-bar--wrp[data-hidden='true'] {
  opacity: 0;
}

.Toastify__progress-bar--bg {
  opacity: var(--toastify-color-progress-bgo);
  width: 100%;
  height: 100%;
}

.Toastify__spinner {
  width: 20px;
  height: 20px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: var(--toastify-spinner-color-empty-area);
  border-right-color: var(--toastify-spinner-color);
  animation: Toastify__spin 0.65s linear infinite;
}

@keyframes Toastify__bounceInRight {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  from {
    opacity: 0;
    transform: translate3d(3000px, 0, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(-25px, 0, 0);
  }
  75% {
    transform: translate3d(10px, 0, 0);
  }
  90% {
    transform: translate3d(-5px, 0, 0);
  }
  to {
    transform: none;
  }
}

@keyframes Toastify__bounceOutRight {
  20% {
    opacity: 1;
    transform: translate3d(-20px, var(--y), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(2000px, var(--y), 0);
  }
}

@keyframes Toastify__bounceInLeft {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  0% {
    opacity: 0;
    transform: translate3d(-3000px, 0, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(25px, 0, 0);
  }
  75% {
    transform: translate3d(-10px, 0, 0);
  }
  90% {
    transform: translate3d(5px, 0, 0);
  }
  to {
    transform: none;
  }
}

@keyframes Toastify__bounceOutLeft {
  20% {
    opacity: 1;
    transform: translate3d(20px, var(--y), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(-2000px, var(--y), 0);
  }
}

@keyframes Toastify__bounceInUp {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  from {
    opacity: 0;
    transform: translate3d(0, 3000px, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(0, -20px, 0);
  }
  75% {
    transform: translate3d(0, 10px, 0);
  }
  90% {
    transform: translate3d(0, -5px, 0);
  }
  to {
    transform: translate3d(0, 0, 0);
  }
}

@keyframes Toastify__bounceOutUp {
  20% {
    transform: translate3d(0, calc(var(--y) - 10px), 0);
  }
  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, calc(var(--y) + 20px), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(0, -2000px, 0);
  }
}

@keyframes Toastify__bounceInDown {
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }
  0% {
    opacity: 0;
    transform: translate3d(0, -3000px, 0);
  }
  60% {
    opacity: 1;
    transform: translate3d(0, 25px, 0);
  }
  75% {
    transform: translate3d(0, -10px, 0);
  }
  90% {
    transform: translate3d(0, 5px, 0);
  }
  to {
    transform: none;
  }
}

@keyframes Toastify__bounceOutDown {
  20% {
    transform: translate3d(0, calc(var(--y) - 10px), 0);
  }
  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, calc(var(--y) + 20px), 0);
  }
  to {
    opacity: 0;
    transform: translate3d(0, 2000px, 0);
  }
}

.Toastify__bounce-enter--top-left,
.Toastify__bounce-enter--bottom-left {
  animation-name: Toastify__bounceInLeft;
}

.Toastify__bounce-enter--top-right,
.Toastify__bounce-enter--bottom-right {
  animation-name: Toastify__bounceInRight;
}

.Toastify__bounce-enter--top-center {
  animation-name: Toastify__bounceInDown;
}

.Toastify__bounce-enter--bottom-center {
  animation-name: Toastify__bounceInUp;
}

.Toastify__bounce-exit--top-left,
.Toastify__bounce-exit--bottom-left {
  animation-name: Toastify__bounceOutLeft;
}

.Toastify__bounce-exit--top-right,
.Toastify__bounce-exit--bottom-right {
  animation-name: Toastify__bounceOutRight;
}

.Toastify__bounce-exit--top-center {
  animation-name: Toastify__bounceOutUp;
}

.Toastify__bounce-exit--bottom-center {
  animation-name: Toastify__bounceOutDown;
}

@keyframes Toastify__zoomIn {
  from {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }
  50% {
    opacity: 1;
  }
}

@keyframes Toastify__zoomOut {
  from {
    opacity: 1;
  }
  50% {
    opacity: 0;
    transform: translate3d(0, var(--y), 0) scale3d(0.3, 0.3, 0.3);
  }
  to {
    opacity: 0;
  }
}

.Toastify__zoom-enter {
  animation-name: Toastify__zoomIn;
}

.Toastify__zoom-exit {
  animation-name: Toastify__zoomOut;
}

@keyframes Toastify__flipIn {
  from {
    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
    animation-timing-function: ease-in;
    opacity: 0;
  }
  40% {
    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
    animation-timing-function: ease-in;
  }
  60% {
    transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
    opacity: 1;
  }
  80% {
    transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
  }
  to {
    transform: perspective(400px);
  }
}

@keyframes Toastify__flipOut {
  from {
    transform: translate3d(0, var(--y), 0) perspective(400px);
  }
  30% {
    transform: translate3d(0, var(--y), 0) perspective(400px) rotate3d(1, 0, 0, -20deg);
    opacity: 1;
  }
  to {
    transform: translate3d(0, var(--y), 0) perspective(400px) rotate3d(1, 0, 0, 90deg);
    opacity: 0;
  }
}

.Toastify__flip-enter {
  animation-name: Toastify__flipIn;
}

.Toastify__flip-exit {
  animation-name: Toastify__flipOut;
}

@keyframes Toastify__slideInRight {
  from {
    transform: translate3d(110%, 0, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideInLeft {
  from {
    transform: translate3d(-110%, 0, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideInUp {
  from {
    transform: translate3d(0, 110%, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideInDown {
  from {
    transform: translate3d(0, -110%, 0);
    visibility: visible;
  }
  to {
    transform: translate3d(0, var(--y), 0);
  }
}

@keyframes Toastify__slideOutRight {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(110%, var(--y), 0);
  }
}

@keyframes Toastify__slideOutLeft {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(-110%, var(--y), 0);
  }
}

@keyframes Toastify__slideOutDown {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(0, 500px, 0);
  }
}

@keyframes Toastify__slideOutUp {
  from {
    transform: translate3d(0, var(--y), 0);
  }
  to {
    visibility: hidden;
    transform: translate3d(0, -500px, 0);
  }
}

.Toastify__slide-enter--top-left,
.Toastify__slide-enter--bottom-left {
  animation-name: Toastify__slideInLeft;
}

.Toastify__slide-enter--top-right,
.Toastify__slide-enter--bottom-right {
  animation-name: Toastify__slideInRight;
}

.Toastify__slide-enter--top-center {
  animation-name: Toastify__slideInDown;
}

.Toastify__slide-enter--bottom-center {
  animation-name: Toastify__slideInUp;
}

.Toastify__slide-exit--top-left,
.Toastify__slide-exit--bottom-left {
  animation-name: Toastify__slideOutLeft;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

.Toastify__slide-exit--top-right,
.Toastify__slide-exit--bottom-right {
  animation-name: Toastify__slideOutRight;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

.Toastify__slide-exit--top-center {
  animation-name: Toastify__slideOutUp;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

.Toastify__slide-exit--bottom-center {
  animation-name: Toastify__slideOutDown;
  animation-timing-function: ease-in;
  animation-duration: 0.3s;
}

@keyframes Toastify__spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
`,J=new Map,Ht=(t,e)=>{nt(()=>{if(typeof document>"u")return;let a=document,o=J.get(a);if(o){e&&o.setAttribute("nonce",e);return}let r=a.createElement("style");r.textContent=t,e&&r.setAttribute("nonce",e),a.head.appendChild(r),J.set(a,r)},[e])};function qt(t){return Ht(Ut,t.nonce),b.createElement(Xt,{...t})}export{dt as R,qt as x,g as y};
